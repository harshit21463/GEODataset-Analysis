
library(ggplot2)
library(GEOquery)
library(limma)
my_id <- "GSE205155"
gse <- getGEO(my_id)
gse <- gse[[1]]
pData(gse) ## print the sample information
fData(gse) ## print the gene annotation

# Normalize the data using quantile normalization
gse_norm <- normalizeBetweenArrays(exprs(gse), method="quantile")

# Print summary statistics of the filtered data
summary(gse_norm)

# Plot the normalized and filtered data
par(mfrow=c(1,2))
exprs_mat <- as.matrix(exprs(gse))

# Plot a boxplot of the expression data
boxplot(exprs_mat, outline=FALSE)
exprs(gse) <- log2(exprs(gse))
boxplot(exprs(gse),outline=FALSE)
# Divide the data into 2 equal groups
group1 <- gse_norm[, 1:77]
group2 <- gse_norm[, 78:154]
group3 <- gse_norm[, 9:96]
# Apply t-test
ttest_res12 <- t.test(group1, group2)
ttest_res13 <- t.test(group1, group3)
ttest_res23 <- t.test(group2, group3)

log_fc <- log2(apply(group2, 1, mean) / apply(group1, 1, mean))

# Print the log fold change for the first 10 genes
head(log_fc, 10)
test_results <- c(ttest_res12, ttest_res13, ttest_res23)
p_values_holm <- p.adjust(test_results$p.value, method = "holm")

# Print the corrected p-values
p_values_holm
volcano_data <- data.frame(log_fc = log_fc, p_values_holm = p_values_holm)
ggplot(volcano_data, aes(x = log_fc, y = -log10(p_values_holm))) +
  geom_point(size = 1.5, alpha = 0.8, color = ifelse(abs(log_fc) > 1 & -log10(p_values_holm) > 1.3, "red", "black")) +
  geom_vline(xintercept = c(-1, 1), linetype = "dashed", color = "gray40") +
  geom_hline(yintercept = -log10(0.05), linetype = "dashed", color = "gray40") +
  labs(title = "Volcano Plot", x = "Log Fold Change", y = "-Log10(Adjusted P-value)") +
  theme_bw()

################################################################
#   Differential expression analysis with limma
library(GEOquery)
library(limma)

# load series and platform data from GEO

gset <- getGEO("GSE205155", GSEMatrix =TRUE, AnnotGPL=FALSE)
if (length(gset) > 1) idx <- grep("GPL14550", attr(gset, "names")) else idx <- 1
gset <- gset[[idx]]

# make proper column names to match toptable 
fvarLabels(gset) <- make.names(fvarLabels(gset))

# group membership for all samples
gsms <- paste0("00000000000000000000000000000000000000000000000000",
               "00000000000000000000000000011111111111111111111111",
               "11111111111111111111111111111111111111111111111111",
               "1111")
sml <- strsplit(gsms, split="")[[1]]

# log2 transformation
ex <- exprs(gset)
qx <- as.numeric(quantile(ex, c(0., 0.25, 0.5, 0.75, 0.99, 1.0), na.rm=T))
LogC <- (qx[5] > 100) ||
  (qx[6]-qx[1] > 50 && qx[2] > 0)
if (LogC) { ex[which(ex <= 0)] <- NaN
exprs(gset) <- log2(ex) }

# assign samples to groups and set up design matrix
gs <- factor(sml)
groups <- make.names(c("dermis","epidermis"))
levels(gs) <- groups
gset$group <- gs
design <- model.matrix(~group + 0, gset)
colnames(design) <- levels(gs)

fit <- lmFit(gset, design)  # fit linear model

# set up contrasts of interest and recalculate model coefficients
cts <- paste(groups[1], groups[2], sep="-")
cont.matrix <- makeContrasts(contrasts=cts, levels=design)
fit2 <- contrasts.fit(fit, cont.matrix)

# compute statistics and table of top significant genes
fit2 <- eBayes(fit2, 0.01)
tT <- topTable(fit2, adjust="fdr", sort.by="B", number=250)
names(tT)
tT <- subset(tT, select=c("ID","adj.P.Val","P.Value","t","B","logFC","GENE_SYMBOL","SEQUENCE"))
write.table(tT, file=stdout(), row.names=F, sep="\t")


# Visualize and quality control test results.
# Build histogram of P-values for all genes. Normal test
# assumption is that most genes are not differentially expressed.
tT2 <- topTable(fit2, adjust="fdr", sort.by="B", number=Inf)
hist(tT2$adj.P.Val, col = "grey", border = "white", xlab = "P-adj",
     ylab = "Number of genes", main = "P-adj value distribution")

# summarize test results as "up", "down" or "not expressed"
dT <- decideTests(fit2, adjust.method="fdr", p.value=0.05)


# volcano plot (log P-value vs log fold change)
colnames(fit2) # list contrast names
ct <- 1        # choose contrast of interest
volcanoplot(fit2, coef=ct, main=colnames(fit2)[ct], pch=20,
            highlight=length(which(dT[,ct]!=0)), names=rep('+', nrow(fit2)))



################################################################
# General expression data analysis
ex <- exprs(gset)

# box-and-whisker plot
dev.new(width=3+ncol(gset)/6, height=5)
ord <- order(gs)  # order samples by group
palette(c("#1B9E77", "#7570B3", "#E7298A", "#E6AB02", "#D95F02",
          "#66A61E", "#A6761D", "#B32424", "#B324B3", "#666666"))
par(mar=c(7,4,2,1))
title <- paste ("GSE205155", "/", annotation(gset), sep ="")
boxplot(ex[,ord], boxwex=0.6, notch=T, main=title, outline=FALSE, las=2, col=gs[ord])
legend("topleft", groups, fill=palette(), bty="n")
dev.off()

library(clusterProfiler)
library(org.Hs.eg.db)
# Set up input data (here, using a vector of example genes)
gene_list <- tT$GENE_SYMBOL

# gene set enrichment analysis using the Gene Ontology Biological Processes database
enrich_result <- enrichGO(gene     = gene_list,
                          OrgDb    = org.Hs.eg.db,
                          keyType  = "SYMBOL",
                          ont      = "BP",
                          pAdjustMethod = "holm",
                          pvalueCutoff = 0.05,
                          qvalueCutoff = 0.2,
                          readable = TRUE)

# View the results
enrich_result@result

# Plot the enriched pathways in a bar graph
barplot(enrich_result, showCategory = 15, xlab = "Enrichment Score")

# Plot the enriched pathways in a dot plot
dotplot(enrich_result, showCategory = 15, title = "Enrichment Score")

lulli <- head(enrich_result@result, 15)
lulli$Description

